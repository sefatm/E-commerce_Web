export const environment = {
  production: true,
  name: 'production',

  apiUrl: 'http://localhost:8080',
  apiTimeout: 30000,

  auth: {
    tokenKey: 'roam_token',
    refreshTokenKey: 'roam_refresh_token',
    userKey: 'roam_user',
    tokenExpiryKey: 'roam_token_expiry',
    defaultExpiry: 3600
  },

  upload: {
    maxFileSize: 5 * 1024 * 1024,
    allowedImageTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
    allowedDocumentTypes: ['application/pdf', 'application/msword'],
    imageQuality: 0.8,
    thumbnailSize: { width: 300, height: 300 },
    mediumSize: { width: 600, height: 600 }
  },

  pagination: {
    defaultPage: 1,
    defaultLimit: 10,
    maxLimit: 100,
    productsPerPage: 12,
    ordersPerPage: 10,
    customersPerPage: 15
  },

  ecommerce: {
    currency: 'BDT',
    currencySymbol: 'Tk',
    currencyPosition: 'before',
    decimalPlaces: 2,
    thousandsSeparator: ',',
    taxEnabled: true,
    defaultTaxRate: 15,
    lowStockThreshold: 10,
    outOfStockThreshold: 0,
    allowGuestCheckout: false,
    enableReviews: true,
    enableWishlist: true,
    enableCompare: true,
    orderPrefix: 'ROAM',
    invoicePrefix: 'INV'
  },

  features: {
    enableDarkMode: true,
    enableMultiLanguage: false,
    enableMultiCurrency: false,
    enableAnalytics: true,
    enableNotifications: true,
    enableChat: false,
    enableProductVariants: true,
    enableDigitalProducts: true,
    enableBulkActions: true,
    enableExport: true,
    enableImport: true
  },

  services: {
    sslCommerz: {
      enabled: false,
      storeId: '',
      storePassword: '',
      isSandbox: true,
      sandboxUrl: 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php',
      liveUrl: 'https://securepay.sslcommerz.com/gwprocess/v4/api.php'
    },
    bKash: {
      enabled: false,
      appKey: '',
      appSecret: '',
      isSandbox: true,
      sandboxUrl: 'https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout',
      liveUrl: 'https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/checkout'
    },
    stripe: {
      enabled: false,
      publishableKey: '',
      secretKey: ''
    },
    cloudinary: {
      enabled: false,
      cloudName: '',
      uploadPreset: '',
      apiKey: '',
      folder: 'roam/products'
    },
    awsS3: {
      enabled: false,
      bucket: '',
      region: 'ap-south-1',
      accessKeyId: '',
      secretAccessKey: ''
    },
    email: {
      provider: 'smtp',
      from: 'noreply@roam.com',
      fromName: 'ROAM Ecommerce'
    },
    sms: {
      provider: 'none',
      twilio: {
        accountSid: '',
        authToken: '',
        fromNumber: ''
      }
    },
    googleAnalytics: {
      enabled: false,
      trackingId: ''
    },
    facebookPixel: {
      enabled: false,
      pixelId: ''
    }
  },

  googleMaps: {
    enabled: false,
    apiKey: '',
    defaultCenter: { lat: 23.8103, lng: 90.4125 },
    defaultZoom: 12
  },

  logging: {
    enabled: false,
    level: 'error',
    logApiCalls: false,
    logErrors: true,
    maxLogEntries: 50
  }
};
