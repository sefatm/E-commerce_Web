import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MainLayoutComponent } from './layout/main-layout/main-layout.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { AddProductComponent } from './modules/products/add-product/add-product.component';
import { ProductListComponent } from './modules/products/product-list/product-list.component';
import { OrderListComponent } from './modules/orders/order-list/order-list.component';
import { OrderDetailsComponent } from './modules/orders/order-details/order-details.component';
import { OrderTrackingComponent } from './modules/orders/order-tracking/order-tracking.component';
import { OrderPaymentComponent } from './modules/orders/order-payment/order-payment.component';
import { OrderReturnComponent } from './modules/orders/order-return/order-return.component';
import { OrderInvoiceComponent } from './modules/orders/order-invoice/order-invoice.component';
import { OrderAnalyticsComponent } from './modules/orders/order-analytics/order-analytics.component';
import { AddCustomerComponent } from './modules/customers/add-customer/add-customer.component';
import { CustomerListComponent } from './modules/customers/customer-list/customer-list.component';
import { CategoryComponent } from './modules/products/category/category.component';
import { BrandComponent } from './modules/products/brand/brand.component';
import { AttributesComponent } from './modules/products/attributes/attributes.component';
import { VariantsComponent } from './modules/products/variants/variants.component';
import { InventoryComponent } from './modules/products/inventory/inventory.component';
import { ReviewComponent } from './modules/products/review/review.component';

import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { CheckoutComponent } from './pages/checkout/checkout.component';
import { OfferComponent } from './modules/coupons/offer/offer.component';
import { CouponComponent } from './modules/coupons/coupon/coupon.component';
import { ShippingZonesComponent } from './modules/shipping/shipping-zones/shipping-zones.component';
import { DeliveryMethodsComponent } from './modules/shipping/delivery-methods/delivery-methods.component';
import { ShipmentTrackingComponent } from './modules/shipping/shipment-tracking/shipment-tracking.component';
import { VendorListComponent } from './modules/vendors/vendor-list/vendor-list.component';
import { VendorPayoutsComponent } from './modules/vendors/vendor-payouts/vendor-payouts.component';
import { SalesReportComponent } from './modules/reports/sales-report/sales-report.component';
import { RevenueReportComponent } from './modules/reports/revenue-report/revenue-report.component';
import { ProductReportComponent } from './modules/reports/product-report/product-report.component';
import { CustomerReportComponent } from './modules/reports/customer-report/customer-report.component';
import { RegisterComponent } from './pages/register/register.component';
import { SettingsComponent } from './modules/settings/settings/settings.component';
import { CreateAdminComponent } from './modules/users/create-admin/create-admin.component';
import { MyOrdersComponent } from './pages/my-orders/my-orders.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { WishlistComponent } from './pages/wishlist/wishlist.component';
import { SellerApplyComponent } from './pages/seller-apply/seller-apply.component';
import { SellerApprovalsComponent } from './modules/sellers/seller-approvals/seller-approvals.component';
import { SellerDashboardComponent } from './modules/sellers/seller-dashboard/seller-dashboard.component';
import { SellerOrdersComponent } from './modules/sellers/seller-orders/seller-orders.component';
import { SellerWithdrawalsComponent } from './modules/sellers/seller-withdrawals/seller-withdrawals.component';
import { ProductApprovalsComponent } from './modules/products/product-approvals/product-approvals.component';
import { CommissionListComponent } from './modules/commissions/commission-list/commission-list.component';
import { ProductDetailComponent } from './pages/product-detail/product-detail.component';
import { PaymentResultComponent } from './pages/payment-result/payment-result.component';
import { SellerCommissionsComponent } from './modules/sellers/seller-commissions/seller-commissions.component';
import { AdminGuard, AuthGuard } from './auth.guard';


const routes: Routes = [

  
  { path: '', component: HomeComponent },
  { path: 'product/:id', component: ProductDetailComponent },
  { path: 'payment/success', component: PaymentResultComponent },
  { path: 'payment/fail', component: PaymentResultComponent },
  { path: 'payment/cancel', component: PaymentResultComponent },
  { path: 'login', component: LoginComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'register', component: RegisterComponent},
  { path: 'checkout', component: CheckoutComponent, canActivate: [AuthGuard] },
  { path: 'my-orders', component: MyOrdersComponent, canActivate: [AuthGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
  { path: 'wishlist', component: WishlistComponent, canActivate: [AuthGuard] },
  { path: 'seller/apply', component: SellerApplyComponent, canActivate: [AuthGuard] },
  {
    path: 'seller',
    component: MainLayoutComponent,
    canActivate: [AuthGuard],
    data: { roles: ['seller', 'vendor', 'admin', 'manager', 'staff'] },
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: SellerDashboardComponent },
      { path: 'orders', component: SellerOrdersComponent },
      { path: 'add-product', component: AddProductComponent },
      { path: 'edit/:id', component: AddProductComponent },
      { path: 'products', component: ProductListComponent },
      { path: 'inventory', component: InventoryComponent },
      { path: 'commissions', component: SellerCommissionsComponent },
      { path: 'withdrawals', component: SellerWithdrawalsComponent },
      { path: 'settings', component: ProfileComponent },
    ]
  },

  { path: 'admin/orders/invoice/:id', component: OrderInvoiceComponent, canActivate: [AdminGuard] },

  {
    path: 'admin', component: MainLayoutComponent, canActivate: [AdminGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },

      { path: 'add', redirectTo: 'list', pathMatch: 'full' },
      { path: 'edit/:id', component: AddProductComponent },
      { path: 'list', component: ProductListComponent },
      { path: 'products/approvals', component: ProductApprovalsComponent },

      { path: 'orders/list', component: OrderListComponent },
      { path: 'orders/details/:id', component: OrderDetailsComponent },
      { path: 'orders/tracking/:id', component: OrderTrackingComponent },
      { path: 'orders/payments', component: OrderPaymentComponent },
      { path: 'orders/returns', component: OrderReturnComponent },
      
      { path: 'orders/analytics', component: OrderAnalyticsComponent },

      { path: 'customers/add', component: AddCustomerComponent },
      { path: 'customers/list', component: CustomerListComponent },
      { path: 'categories', component: CategoryComponent},
      { path: 'brands', component: BrandComponent},

      { path: 'attributes', component: AttributesComponent },
      { path: 'variants', component: VariantsComponent },
      { path: 'inventory', redirectTo: 'list', pathMatch: 'full' },
      { path: 'reviews', component: ReviewComponent },

      { path: 'coupons', component: CouponComponent },
      { path: 'offers',  component: OfferComponent  },

      { path: 'shipping-zones', component: ShippingZonesComponent },
      { path: 'delivery-methods', component: DeliveryMethodsComponent },
      { path: 'tracking', component: ShipmentTrackingComponent },

      { path: 'vendors/list', redirectTo: 'sellers/approvals', pathMatch: 'full' },
      { path: 'vendors/payouts', redirectTo: 'sellers/withdrawals', pathMatch: 'full' },
      { path: 'sellers/approvals', component: SellerApprovalsComponent },
      { path: 'sellers/dashboard', redirectTo: 'sellers/approvals', pathMatch: 'full' },
      { path: 'sellers/withdrawals', component: SellerWithdrawalsComponent },
      { path: 'commissions', component: CommissionListComponent },

      { path: 'reports/sales',    component: SalesReportComponent    },
      { path: 'reports/revenue',  component: RevenueReportComponent  },
      { path: 'reports/products', component: ProductReportComponent  },
      { path: 'reports/customers',component: CustomerReportComponent },

      { path: 'settings/general',  component: SettingsComponent },
      { path: 'users/create-admin', component: CreateAdminComponent },
      

    ]
  },

  { path: '**', redirectTo: '' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
