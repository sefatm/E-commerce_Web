import { Component, Output, EventEmitter } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import { WishlistService } from 'src/app/services/wishlist.service';

@Component({
  selector: 'app-site-header',
  templateUrl: './site-header.component.html',
  styleUrls: ['./site-header.component.css']
})
export class SiteHeaderComponent {

  cartCount = 0;
  wishlistCount = 0;
  showUserMenu = false;
  isLoggedIn = false;
  isAdmin = false;
  isSeller = false;
  userName = 'Account';
  userPhoto = '';

  @Output() searchEvent = new EventEmitter<string>();

  constructor(
    public cartService: CartService,
    public authService: AuthService,
    public router: Router,
    private wishlistService: WishlistService
  ) {
    this.cartService.currentCartItems.subscribe(() => {
      this.cartCount = this.cartService.getCartCount();
    });

    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
      this.isAdmin = this.authService.isAdmin();
      this.isSeller = this.authService.isSeller();
      this.userName = user?.name ?? 'Account';
      this.userPhoto = this.photoUrl(user?.profileImage);
      if (user?.id) {
        this.wishlistService.load(user.id).subscribe();
      } else {
        this.wishlistService.clear();
      }
    });

    this.wishlistService.items$.subscribe(items => {
      this.wishlistCount = items?.length || 0;
    });
  }

  onSearchInput(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.searchEvent.emit(value);
  }

  onSearchClick(value: string) {
    this.searchEvent.emit(value.trim());
  }

  openCart() {
    this.cartService.openCart();
  }

  goToLogin() {
    this.router.navigateByUrl('/login');
  }

  toggleUserMenu() {
    this.showUserMenu = !this.showUserMenu;
  }

  logout() {
    this.authService.logout();
    this.showUserMenu = false;
    this.router.navigateByUrl('/');
  }

  photoUrl(image: string | null | undefined): string {
    if (!image) return '';
    if (image.startsWith('http')) return image;
    return 'http://localhost:8080/uploads/' + image;
  }

  userInitial(): string {
    return (this.userName || 'A').substring(0, 1).toUpperCase();
  }
}
