import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { NavbarComponent } from './layout/navbar/navbar.component';
import { FooterComponent } from './layout/footer/footer.component';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { AddProductComponent } from './modules/products/add-product/add-product.component';
import { ProductListComponent } from './modules/products/product-list/product-list.component';
import { OrderListComponent } from './modules/orders/order-list/order-list.component';
import { OrderDetailsComponent } from './modules/orders/order-details/order-details.component';
import { OrderTrackingComponent } from './modules/orders/order-tracking/order-tracking.component';
import { OrderPaymentComponent } from './modules/orders/order-payment/order-payment.component';
import { OrderReturnComponent } from './modules/orders/order-return/order-return.component';
import { OrderInvoiceComponent } from './modules/orders/order-invoice/order-invoice.component';
import { OrderAnalyticsComponent } from './modules/orders/order-analytics/order-analytics.component';
import { AddCustomerComponent } from './modules/customers/add-customer/add-customer.component';
import { CustomerListComponent } from './modules/customers/customer-list/customer-list.component';
import { CategoryComponent } from './modules/products/category/category.component';
import { BrandComponent } from './modules/products/brand/brand.component';
import { AttributesComponent } from './modules/products/attributes/attributes.component';
import { VariantsComponent } from './modules/products/variants/variants.component';
import { InventoryComponent } from './modules/products/inventory/inventory.component';
import { ReviewComponent } from './modules/products/review/review.component';
import { SiteHeaderComponent } from './components/site-header/site-header.component';
import { CategoryNavComponent } from './components/category-nav/category-nav.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { CartModalComponent } from './components/cart-modal/cart-modal.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { CheckoutComponent } from './pages/checkout/checkout.component';
import { CouponComponent } from './modules/coupons/coupon/coupon.component';
import { OfferComponent } from './modules/coupons/offer/offer.component';
import { ShippingZonesComponent } from './modules/shipping/shipping-zones/shipping-zones.component';
import { DeliveryMethodsComponent } from './modules/shipping/delivery-methods/delivery-methods.component';
import { ShipmentTrackingComponent } from './modules/shipping/shipment-tracking/shipment-tracking.component';
import { VendorListComponent } from './modules/vendors/vendor-list/vendor-list.component';
import { VendorPayoutsComponent } from './modules/vendors/vendor-payouts/vendor-payouts.component';
import { SalesReportComponent } from './modules/reports/sales-report/sales-report.component';
import { RevenueReportComponent } from './modules/reports/revenue-report/revenue-report.component';
import { ProductReportComponent } from './modules/reports/product-report/product-report.component';
import { CustomerReportComponent } from './modules/reports/customer-report/customer-report.component';
import { RegisterComponent } from './pages/register/register.component';
import { SettingsComponent } from './modules/settings/settings/settings.component';
import { CreateAdminComponent } from './modules/users/create-admin/create-admin.component';
import { MyOrdersComponent } from './pages/my-orders/my-orders.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { WishlistComponent } from './pages/wishlist/wishlist.component';
import { SellerApplyComponent } from './pages/seller-apply/seller-apply.component';
import { SellerApprovalsComponent } from './modules/sellers/seller-approvals/seller-approvals.component';
import { SellerDashboardComponent } from './modules/sellers/seller-dashboard/seller-dashboard.component';
import { SellerOrdersComponent } from './modules/sellers/seller-orders/seller-orders.component';
import { SellerWithdrawalsComponent } from './modules/sellers/seller-withdrawals/seller-withdrawals.component';
import { ProductApprovalsComponent } from './modules/products/product-approvals/product-approvals.component';
import { CommissionListComponent } from './modules/commissions/commission-list/commission-list.component';
import { ProductDetailComponent } from './pages/product-detail/product-detail.component';
import { SellerCommissionsComponent } from './modules/sellers/seller-commissions/seller-commissions.component';
import { JwtInterceptor } from './interceptors/jwt.interceptor';
import { PaymentResultComponent } from './pages/payment-result/payment-result.component';


@NgModule({
  declarations: [
    AppComponent,
    
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    MainLayoutComponent,
    DashboardComponent,
    AddProductComponent,
    ProductListComponent,
    OrderListComponent,
    OrderDetailsComponent,
    OrderTrackingComponent,
    OrderPaymentComponent,
    OrderReturnComponent,
    OrderInvoiceComponent,
    OrderAnalyticsComponent,
    AddCustomerComponent,
    CustomerListComponent,
    CategoryComponent,
    BrandComponent,
    AttributesComponent,
    VariantsComponent,
    InventoryComponent,
    ReviewComponent,
    SiteHeaderComponent,
    CategoryNavComponent,
    ProductCardComponent,
    CartModalComponent,
    HomeComponent,
    LoginComponent,
    ForgotPasswordComponent,
    CheckoutComponent,
    CouponComponent,
    OfferComponent,
    ShippingZonesComponent,
    DeliveryMethodsComponent,
    ShipmentTrackingComponent,
    VendorListComponent,
    VendorPayoutsComponent,
    SalesReportComponent,
    RevenueReportComponent,
    ProductReportComponent,
    CustomerReportComponent,
    RegisterComponent,
    SettingsComponent,
    CreateAdminComponent,
    MyOrdersComponent,
    ProfileComponent,
    WishlistComponent,
    SellerApplyComponent,
    SellerApprovalsComponent,
    SellerDashboardComponent,
    SellerOrdersComponent,
    SellerWithdrawalsComponent,
    ProductApprovalsComponent,
    CommissionListComponent,
    ProductDetailComponent,
    SellerCommissionsComponent,
    PaymentResultComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
