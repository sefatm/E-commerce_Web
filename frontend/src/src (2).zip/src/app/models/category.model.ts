export interface Category {
  id: number;
  name: string;
  description: string;
  parent?: string;
}